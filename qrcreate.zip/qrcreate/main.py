import os
import sys
import qrcode
from rich import print

os.system('cls')
os.system('color 0F')
xhome = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
print('[#00ccff]WEB[/][#ffffff]-[/][#00ccff]URL[/] [#5e5e5e]([/][#ffd500]http://www.website.com[/][#5e5e5e])[/] [#ff006f]>>[/]', end='')
xdata = str(input(' '))
xfile = str(xdata).replace(' ','-').replace('https://','').replace('http://','').replace('m.','').replace('www.','').replace('.com','').replace('.org','').replace('.org','').replace('.net','').replace('.io','').replace('.html','').replace('.htm','').replace('.php','').replace('.tv','').replace('.css','').replace('.js','').replace('.aspx','').replace('.me','').replace('.mob','').strip()
ximg = qrcode.make(xdata)
ximg.save(f'{xhome}\\{xfile}.png')
os.system(f'START {xhome}\\{xfile}.png &')
os.system('cls')
os.system('color 0F')
os.system('cls')
sys.exit()