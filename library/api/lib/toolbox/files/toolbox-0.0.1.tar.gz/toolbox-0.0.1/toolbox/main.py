import os
import sys
import hashlib
import platform

tb_version = '0.0.1'

def help():
	if str(platform.system()).lower() == 'windows':
		os.system('cls')
	else:
		os.system('clear')

	print(f'ToolBox v{tb_version}')
	print(' ')
	print('IMPORT..')
	print('	import toolbox')
	print(' ')
	print('AVAILABLE FUNCTIONS..')
	print('# Clear Console Display..')
	print('	toolbox.clear()')
	print('# Render MD5 Hash Code from String..')
	print('	toolbox.md5("Hello World!")')
	print('# Render HEX Coding from String..')
	print('	toolbox.hex.enc("Hello World!")')
	print('# Render String from HEX Coding..')
	print('	toolbox.hex.dec("48656c6c6f20576f726c6421")')
	print(' ')
	print('for more info visit..')
	print('	https://alectramell.github.io/library/api/lib/toolbox')

def clear():
	if str(platform.system()).lower() == 'windows':
		os.system('cls')
	else:
		os.system('clear')

def md5(xvar):
	import hashlib
	yvar = hashlib.md5(xvar.encode())
	return(yvar.hexdigest())

class hex:

	def enc(xvar):
		xvar = str(xvar)
		xdat = xvar.encode().hex()
		return xdat

	def dec(svar):
		svar = str(svar)
		sdat = bytes.fromhex(svar).decode('utf-8')
		return sdat