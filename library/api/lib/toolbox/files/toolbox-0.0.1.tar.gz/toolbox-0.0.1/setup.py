from setuptools import setup

setup(
	name='toolbox',
	version='0.0.1',
	description='system tools module for python3',
	author='Alec Tramell',
	author_email='alectramell@gmail.com',
	url='https://alectramell.github.io/library/api/lib/toolbox',
	#install_requires=['hashlib>=1']
	packages=['toolbox']
)