from setuptools import setup

setup(
	name='shift',
	version='0.0.1',
	description='shift encryption for python3',
	author='Tramell Software',
	url='https://alectramell.github.io/library/api/lib/shift',
	packages=['shift']
)