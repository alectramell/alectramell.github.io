import os
import re
import sys
import hashlib
import platform

shift_version = '0.0.1'

def help():
	if str(platform.system()).lower() == 'windows':
		os.system('cls')
	else:
		os.system('clear')

	print(f'Shift v{shift_version}')
	print(' ')
	print('IMPORT..')
	print('	import shift')
	print(' ')
	print('AVAILABLE FUNCTIONS..')
	print('# Encrpyt with key set as 2..')
	print('	shift.enc("Hello World!", 2)')
	print(' ')
	print('# Decrpyt with key set as 2..')
	print('	shift.dec("2e34382e31342e31372e31312e30332e35322e33332e30342e31312e31312e3134", 2)')
	print(' ')
	print('for more info visit..')
	print('	https://alectramell.github.io/library/api/lib/shift')

xbook = {
"a":".00",
"b":".01",
"c":".02",
"d":".03",
"e":".04",
"f":".05",
"g":".06",
"h":".07",
"i":".08",
"j":".09",
"k":".10",
"l":".11",
"m":".12",
"n":".13",
"o":".14",
"p":".15",
"q":".16",
"r":".17",
"s":".18",
"t":".19",
"u":".20",
"v":".21",
"w":".22",
"x":".23",
"y":".24",
"z":".25",
"A":".26",
"B":".27",
"C":".28",
"D":".29",
"E":".30",
"F":".31",
"G":".32",
"H":".33",
"I":".34",
"J":".35",
"K":".36",
"L":".37",
"M":".38",
"N":".39",
"O":".40",
"P":".41",
"Q":".42",
"R":".43",
"S":".44",
"T":".45",
"U":".46",
"V":".47",
"W":".48",
"X":".49",
"Y":".50",
"Z":".51",
"!":".52",
"@":".53",
"#":".54",
"$":".55",
"%":".56",
"^":".57",
"&":".58",
"*":".59",
"(":".60",
")":".61",
"-":".62",
"_":".63",
"=":".64",
"+":".65",
".":".66",
",":".67",
"<":".68",
">":".69",
"?":".70",
":":".71",
"'":".72",
'"':".73",
"[":".74",
"]":".75",
"{":".76",
"}":".77",
"|":".78",
"\\":".79",
"/":".80",
" ":".81",
"0":".82",
"1":".83",
"2":".84",
"3":".85",
"4":".86",
"5":".87",
"6":".88",
"7":".89",
"8":".90",
"9":".91"
}

zbook = dict(zip(xbook.values(), xbook.keys()))

class hex:

	def enc(xvar):
		xvar = str(xvar)
		xdat = xvar.encode().hex()
		return xdat

	def dec(svar):
		svar = str(svar)
		sdat = bytes.fromhex(svar).decode('utf-8')
		return sdat

def enc(xvar, xkey):
	xvar = str(xvar)
	xkey = int(xkey)
	alib = re.findall('.', xvar)
	elib = []
	flib = []
	for i in alib[0:len(alib)//xkey]:
		elib.append(i)
	for i in alib[len(alib)//xkey:]:
		flib.append(i)

	apart = str(''.join(elib).strip())
	bpart = str(''.join(flib).strip())
	xmid = str(bpart+apart)
	midbox = []

	for i in re.findall('.', xmid):
		midbox.append(hex.enc(xbook[i]))

	outbox = str(''.join(midbox).strip())
	return outbox

def dec(xvar, xkey):
	xvar = str(xvar)
	xkey = int(xkey)
	xmid = []
	xout = []
	xfin = []
	aout = []
	bout = []
	for i in re.findall('..', xvar):
		xmid.append(hex.dec(i))

	for i in re.findall('...', ''.join(xmid).strip()):
		xout.append(i)

	for i in xout:
		xfin.append(zbook[i])

	for z in xfin[xkey+1:]:
		aout.append(z)

	for u in xfin[0:xkey+1]:
		bout.append(u)

	finoutput = str(''.join(aout+bout))

	return finoutput