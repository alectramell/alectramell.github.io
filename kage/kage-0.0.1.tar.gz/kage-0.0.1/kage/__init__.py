from .main import *

__name__ = 'kage'
__version__ = '0.0.1'
__author__ = 'Tramell Software'
__description__ = 'shadow file rendering'