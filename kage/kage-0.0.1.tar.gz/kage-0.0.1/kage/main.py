import os
import re
import sys
import platform

def clear():
	if str(platform.system()).lower() == 'windows':
		os.system('cls')
	else:
		os.system('clear')

class hex:

	def enc(xvar):
		xvar = str(xvar)
		xdat = xvar.encode().hex()
		return xdat

	def dec(svar):
		svar = str(svar)
		sdat = bytes.fromhex(svar).decode('utf-8')
		return sdat

def enc(xword):
	xword = str(xword)
	zword = str(hex.enc(xword))
	xout = str(zword[::-1])
	return xout

def dec(xword):
	xword = str(xword)
	zword = str(xword[::-1])
	xout = str(hex.dec(zword))
	return xout