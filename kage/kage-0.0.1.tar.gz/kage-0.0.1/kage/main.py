import os
import sys
import hashlib
import platform

def clear():
	if str(platform.system()).lower() == 'windows':
		os.system('cls')
	else:
		os.system('clear')

def md5(xvar):
	import hashlib
	yvar = hashlib.md5(xvar.encode())
	return(yvar.hexdigest())

def sha256(xvar):
	import hashlib
	yvar = hashlib.sha256(xvar.encode())
	return(yvar.hexdigest())

def create(xuser=None, xpass=None):
	if xuser == None or xpass == None:
		pass
	else:
		xnam = str(md5(xuser))
		astr = str(f'{xuser}:{xpass}')
		zstr = str(astr[::-1])
		xstr = str(sha256(zstr))
		xdat = bytes(xstr, encoding='utf-8')
		if os.path.isfile(f'{os.getcwd()}\\{xnam}.bin'):
			print('[ERR] cannot complete data render')
		else:
			with open(f'{os.getcwd()}\\{xnam}.bin','wb') as bf:
				bf.write(xdat)
			

def check(xuser=None, xpass=None):
	if xuser == None or xpass == None:
		pass
	else:
		xnam = str(md5(xuser))
		astr = str(f'{xuser}:{xpass}')
		zstr = str(astr[::-1])
		xstr = str(sha256(zstr))
		xdat = bytes(xstr, encoding='utf-8')
		if os.path.isfile(f'{os.getcwd()}\\{xnam}.bin'):
			xenc = open(f'{os.getcwd()}\\{xnam}.bin','rb').read()
			if xdat == xenc:
				return True
			else:
				return False
		else:
			return False
