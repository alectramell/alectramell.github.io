import os
import sys
import hashlib
import platform

def clear():
	import os
	if str(platform.system()).lower() == 'windows':
		os.system('cls')
	else:
		os.system('clear')

def md5(xvar):
	import hashlib
	yvar = hashlib.md5(xvar.encode())
	return(yvar.hexdigest())

def sha256(xvar):
	import hashlib
	yvar = hashlib.sha256(xvar.encode())
	return(yvar.hexdigest())

def create(xuser, xpass):
	xuser = str(xuser)
	xpass = str(xpass)
	xcred = str(f'{xuser}:{xpass}')
	xcred = str(xcred[::-1])
	xcred = str(sha256(xcred))
	xcred = bytes(xcred, encoding='utf-8')
	filename = str(md5(xuser))
	filename = str(f'{filename}.bin')
	xfile = open(f'{os.getcwd()}\\{filename}','wb')
	xfile.write(xcred.strip())
	xfile.close()

def check(xuser, xpass):
	xuser = str(xuser)
	xpass = str(xpass)
	xcred = str(f'{xuser}:{xpass}')
	xcred = str(xcred[::-1])
	xcred = str(sha256(xcred))
	filename = str(md5(xuser))
	filename = str(f'{filename}.bin')
	try:
		xdata = open(f'{os.getcwd()}\\{filename}','r').read()
		xdata = str(xdata.strip())
		if xcred == xdata:
			return True
		else:
			return False
	except:
		pass