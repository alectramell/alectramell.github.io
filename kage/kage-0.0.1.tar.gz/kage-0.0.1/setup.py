from setuptools import setup

setup(
	name='kage',
	version='0.0.1',
	description='encryption method',
	packages=['kage']
)