from setuptools import setup

setup (
	name = 'kage',
	version = '0.0.1',
	author = 'Tramell Software',
	description = 'shadow file rendering',
	packages = ['kage'],
	install_requires = ['lib-platform>=1.0','platformdirs>=2.0']
)