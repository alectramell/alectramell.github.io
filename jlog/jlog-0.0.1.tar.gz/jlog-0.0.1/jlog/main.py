import os
import sys
import json
import platform

def clear():
	if str(platform.system()).lower() == 'windows':
		os.system('cls')
	else:
		os.system('clear')

def set(xpath, xvar, xval):
	if os.path.isfile(xpath):
		zdata = open(xpath,'r').read()
		if f'"{xvar}"' in zdata:
			xmid = json.loads(zdata)
			xdata = zdata.replace(f'''"{xvar}":"{xmid[f'{xvar}']}"''',f'''"{xvar}":"{xval}"''')
			xdata = f'''{xdata.strip()}'''
			with open(xpath,'w') as xfile:
				xfile.write(xdata)
		else:
			xdata = zdata.replace('}','')
			xdata = f'''{xdata.strip()},
	"{xvar}":"{xval}"
}}'''
			with open(xpath,'w') as xfile:
				xfile.write(xdata)
	else:
		zdata = f'''{{
	"{xvar}":"{xval}"
}}'''
		open(xpath,'w').write(zdata)

def get(xpath, xvar):
	if os.path.isfile(xpath):
		xlib = open(xpath,'r').read()
		xout = json.loads(xlib)
		return xout[f'{xvar}']
	else:
		pass

def delete(xpath):
	if os.path.isfile(xpath):
		os.remove(xpath)
	else:
		pass

set('myfile.json','a2','poop')