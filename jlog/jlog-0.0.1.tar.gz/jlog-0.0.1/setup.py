from setuptools import setup

setup (
	name='jlog',
	version='0.0.1',
	packages=['jlog']
)