from setuptools import setup

setup (
	name='jlog',
	version='0.0.2',
	packages=['jlog']
)