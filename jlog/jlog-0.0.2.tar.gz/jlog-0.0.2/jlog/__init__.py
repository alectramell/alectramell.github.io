from .main import *

__name__ = 'jlog'
__version__ = '0.0.2'