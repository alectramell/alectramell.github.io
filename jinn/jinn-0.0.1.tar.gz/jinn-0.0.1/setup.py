from setuptools import setup

setup (
	name = 'jinn',
	version = '0.0.1',
	author = 'Tramell Software',
	packages = ['jinn']
)