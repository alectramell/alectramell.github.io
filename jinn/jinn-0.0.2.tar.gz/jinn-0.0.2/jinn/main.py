import os
import sys
import platform

def clear():
	OSname = str(platform.system()).lower()
	if OSname == 'windows':
		os.system('cls')
	else:
		os.system('clear')

class hex:

	def enc(xvar):
		xvar = str(xvar)
		xdat = xvar.encode().hex()
		return xdat

	def dec(svar):
		svar = str(svar)
		sdat = bytes.fromhex(svar).decode('utf-8')
		return sdat

def read(xfile):
	xfile = str(xfile)
	if os.path.isfile(xfile):
		xdata = open(xfile,'r').read()
		xdata = str(xdata[::-1])
		xdata = str(hex.dec(xdata))
	return xdata

def write(xfile, xdata):
	xfile = str(xfile)
	xdata = str(hex.enc(xdata))
	xdata = str(xdata[::-1])
	if os.path.isfile(xfile):
		pass
	else:
		try:
			open(xfile,'w').write(xdata)
		except:
			pass