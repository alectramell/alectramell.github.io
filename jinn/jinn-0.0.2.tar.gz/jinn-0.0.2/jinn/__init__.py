from .main import *

__name__ = 'jinn'
__version__ = '0.0.2'
__author__ = 'Tramell Software'